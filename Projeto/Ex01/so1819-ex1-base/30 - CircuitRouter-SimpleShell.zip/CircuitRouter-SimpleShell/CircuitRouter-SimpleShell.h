#ifndef CIRCUITROUTER_SIMPLESHELL_H
#define CIRCUITROUTER_SIMPLESHELL_H

#define MAX_BUFFER 256

static void displayUsage (const char* appName);

typedef struct process *process_t;

#endif